package com.andrewknell.code;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodeApplicationTests {

	@Test
	void contextLoads() {
	}

}
